// 모든 프레임(iframe 포함)에 주입됨. 프레임별로 독립 실행.
(() => {
  if (window.__beonyeogiInjected) return;
  window.__beonyeogiInjected = true;

  const HANGUL_RE = /[가-힣]/;
  const LATIN_RE = /[a-zA-Z]/;
  const SKIP_TAGS = new Set([
    "SCRIPT",
    "STYLE",
    "NOSCRIPT",
    "TEXTAREA",
    "INPUT",
    "CODE",
    "PRE",
  ]);

  const processed = new WeakSet();
  let active = false;
  let observer = null;
  let toastTimer = null;

  function ensureToast() {
    if (window.top !== window) return null; // 최상위 프레임에서만 토스트 표시
    let toast = document.getElementById("beonyeogi-toast");
    if (toast) return toast;

    const style = document.createElement("style");
    style.textContent = `
      @font-face {
        font-family: 'Beonyeogi-Toast';
        src: url('${chrome.runtime.getURL("fonts/Pretendard-Medium.woff2")}') format('woff2');
        font-weight: 500;
      }
      #beonyeogi-toast {
        all: initial;
        position: fixed;
        right: 20px;
        top: 20px;
        z-index: 2147483647;
        background: #1A1A1A;
        color: #FAF9F6;
        border: 2.25px solid #222222;
        padding: 10px 16px;
        font-family: 'Beonyeogi-Toast', -apple-system, sans-serif;
        font-size: 13px;
        font-weight: 500;
        letter-spacing: -0.02em;
        line-height: 1.6;
        opacity: 0;
        transform: translateY(-8px);
        transition: opacity 0.25s ease, transform 0.25s ease;
        pointer-events: none;
      }
      #beonyeogi-toast.show {
        opacity: 1;
        transform: translateY(0);
      }
    `;
    document.documentElement.appendChild(style);

    toast = document.createElement("div");
    toast.id = "beonyeogi-toast";
    document.documentElement.appendChild(toast);
    return toast;
  }

  function showToast(text, holdMs = 2200) {
    const toast = ensureToast();
    if (!toast) return;
    toast.textContent = text;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), holdMs);
  }

  function isTranslatable(node) {
    const text = node.nodeValue;
    if (!text || !text.trim()) return false;
    if (HANGUL_RE.test(text)) return false; // 이미 한국어 포함 → 건너뜀
    if (!LATIN_RE.test(text)) return false; // 영문자 없는 텍스트(숫자·기호만)는 스킵
    // 커서 반응형 타이포그래피 등에서 단어를 글자 하나씩 별도 <span>으로 쪼개
    // 렌더링하는 경우가 흔한데, 그 한 글자짜리 노드를 개별로 번역 요청하면
    // Google 번역이 "알파벳 이름 읽기"로 응답해 글자수프가 된다
    // (예: T→티, A→에이, I→나, &→그리고). 단어 단위가 아닌 한 글자는 건너뜀.
    if (text.trim().length === 1) return false;

    const parent = node.parentElement;
    if (!parent) return false;
    if (SKIP_TAGS.has(parent.tagName)) return false;
    if (parent.isContentEditable) return false;
    if (parent.closest('[contenteditable="true"]')) return false;

    return true;
  }

  function collectTextNodes(root) {
    if (root.nodeType === Node.TEXT_NODE) {
      return !processed.has(root) && isTranslatable(root) ? [root] : [];
    }
    if (root.nodeType !== Node.ELEMENT_NODE) return [];

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    const nodes = [];
    let n;
    while ((n = walker.nextNode())) {
      if (!processed.has(n) && isTranslatable(n)) nodes.push(n);
    }
    return nodes;
  }

  const CHUNK_SIZE = 12; // 청크 단위로 나눠 동시에 보내면 화면에 결과가 순차적으로 빨리 채워짐

  function chunkArray(arr, size) {
    const chunks = [];
    for (let i = 0; i < arr.length; i += size) chunks.push(arr.slice(i, i + size));
    return chunks;
  }

  async function translateChunk(nodes) {
    const texts = [...new Set(nodes.map((n) => n.nodeValue))];
    let result;
    try {
      result = await chrome.runtime.sendMessage({
        type: "BEONYEOGI_TRANSLATE",
        texts,
      });
    } catch (e) {
      return; // 확장 컨텍스트 무효화 등
    }
    if (!result?.map) return;

    nodes.forEach((n) => {
      const translated = result.map[n.nodeValue];
      if (translated) n.nodeValue = translated;
    });
  }

  function translateNodes(nodes) {
    if (!nodes.length) return;
    nodes.forEach((n) => processed.add(n));
    // 청크마다 별도 메시지로 동시 발송 → 실제 동시 요청 수 제한은 background.js의 전역 세마포어가 담당
    chunkArray(nodes, CHUNK_SIZE).forEach((group) => translateChunk(group));
  }

  function translatePage() {
    translateNodes(collectTextNodes(document.body));
  }

  function startObserving() {
    if (observer) return;
    observer = new MutationObserver((mutations) => {
      const newNodes = [];
      for (const m of mutations) {
        m.addedNodes.forEach((added) => {
          newNodes.push(...collectTextNodes(added));
        });
      }
      if (newNodes.length) translateNodes(newNodes);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function stopObserving() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  // YouTube 자막(캡션) 자동 켜기 — 자막 텍스트도 일반 DOM 텍스트라
  // 위 translateNodes/observer 로직이 그대로 번역해준다. 여기선 "꺼져있는
  // 자막을 켜는 것"만 담당한다 (라이브 스트리밍 중 실시간 갱신되는 자막은
  // 범위 밖 — MutationObserver는 새로 추가되는 자막 노드만 감지한다).
  function isYouTubePlayerPage() {
    if (!/(^|\.)youtube\.com$/.test(location.hostname)) return false;
    return location.pathname === "/watch" || location.pathname.startsWith("/embed/");
  }

  let ytNavListenerAdded = false;

  // 버튼을 "찾았다"와 "실제로 켜졌다"는 다르다 — 유튜브 플레이어는 컨트롤바
  // DOM(스켈레톤)이 실제 클릭 핸들러가 붙기 전에 먼저 나타나기도 해서, 너무
  // 이른 시점의 클릭은 씹힐 수 있다. 그래서 클릭 한 번으로 끝내지 않고,
  // aria-pressed가 실제로 "true"가 될 때까지 재시도한다.
  function tryEnableYouTubeCaptionsOnce() {
    const btn = document.querySelector(".ytp-subtitles-button");
    if (!btn) return false;
    if (btn.getAttribute("aria-pressed") === "true") return true;
    btn.click();
    return false;
  }

  function pollUntilCaptionsOn() {
    if (tryEnableYouTubeCaptionsOnce()) return;
    const poll = setInterval(() => {
      if (tryEnableYouTubeCaptionsOnce()) clearInterval(poll);
    }, 500);
    setTimeout(() => clearInterval(poll), 15000); // 플레이어가 안 뜨면 포기
  }

  function watchYouTubeCaptions() {
    if (!isYouTubePlayerPage()) return;
    pollUntilCaptionsOn();

    if (!ytNavListenerAdded) {
      ytNavListenerAdded = true;
      // 유튜브는 SPA라 다른 영상으로 넘어가도 페이지가 새로 로드되지 않음
      document.addEventListener("yt-navigate-finish", () => {
        setTimeout(pollUntilCaptionsOn, 800);
      });
    }
  }

  function start() {
    active = true;
    showToast("번역이가 번역 중...");
    translatePage();
    startObserving();
    watchYouTubeCaptions();
  }

  function stop() {
    active = false;
    showToast("번역이 중지됨", 1400);
    stopObserving();
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === "BEONYEOGI_TOGGLE") {
      if (active) stop();
      else start();
      // 껐다 켠 상태를 저장해서, 탭을 전환하거나 새로고침해도 다시
      // 제멋대로 켜지지 않고 사용자가 마지막으로 선택한 상태를 유지한다.
      chrome.storage.local.set({ beonyeogiEnabled: active });
      sendResponse({ active });
    } else if (msg?.type === "BEONYEOGI_STATUS") {
      sendResponse({ active });
    }
  });

  // 저장된 설정이 없으면(처음 설치 등) 기본값은 켜짐.
  chrome.storage.local.get({ beonyeogiEnabled: true }, (result) => {
    if (result.beonyeogiEnabled) start();
  });
})();
